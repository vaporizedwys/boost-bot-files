"""
discord.ext.pages
~~~~~~~~~~~~~~~~~~~~~
An extension module to provide useful menu options.

:copyright: 2021-present Pycord-Development
:license: MIT, see LICENSE for more details.
"""

from .pagination import *
